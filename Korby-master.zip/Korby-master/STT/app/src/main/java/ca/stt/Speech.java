package ca.stt;

import android.speech.tts.TextToSpeech;
import java.lang.Thread;

/**
 * Created by cpadk on 4/5/2018.
 */

public class Speech extends Thread {
    String threadName = "";
    private TextToSpeech t1;
    Thread t;
    String phrase = "";

    public Speech(){
        threadName = "Speech";
        System.out.println("Creating Speech thread.");
    }

    public void run() {
        t1.speak(phrase, TextToSpeech.QUEUE_FLUSH, null);
        System.out.println("Ran 'run' method.");

    }

    public void start(TextToSpeech t1in, String phraseIn) {
        t1 = t1in;
        phrase = phraseIn;

        if (t == null) {
            t = new Thread(this, threadName);
            t.start();
        } else {
            t.run();
        }

    }
}
